import { useEffect, useState, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { Volume2, Square, Play, Pause, Download, Keyboard } from "lucide-react";

interface Note {
  note: string;
  frequency: number;
  key: string;
}

interface RecordedNote {
  note: string;
  frequency: number;
  timestamp: number;
  instrument: string;
}

// Piano notes - Extended range (3 octaves)
const PIANO_NOTES: Note[] = [
  // Octave 3 (lower register)
  { note: "C3", frequency: 130.81, key: "z" },
  { note: "C#3", frequency: 138.59, key: "s" },
  { note: "D3", frequency: 146.83, key: "x" },
  { note: "D#3", frequency: 155.56, key: "d" },
  { note: "E3", frequency: 164.81, key: "c" },
  { note: "F3", frequency: 174.61, key: "v" },
  { note: "F#3", frequency: 185.0, key: "g" },
  { note: "G3", frequency: 196.0, key: "b" },
  { note: "G#3", frequency: 207.65, key: "h" },
  { note: "A3", frequency: 220.0, key: "n" },
  { note: "A#3", frequency: 233.08, key: "j" },
  { note: "B3", frequency: 246.94, key: "m" },

  // Octave 4 (middle register)
  { note: "C4", frequency: 261.63, key: "q" },
  { note: "C#4", frequency: 277.18, key: "2" },
  { note: "D4", frequency: 293.66, key: "w" },
  { note: "D#4", frequency: 311.13, key: "3" },
  { note: "E4", frequency: 329.63, key: "e" },
  { note: "F4", frequency: 349.23, key: "r" },
  { note: "F#4", frequency: 369.99, key: "5" },
  { note: "G4", frequency: 392.0, key: "t" },
  { note: "G#4", frequency: 415.3, key: "6" },
  { note: "A4", frequency: 440.0, key: "y" },
  { note: "A#4", frequency: 466.16, key: "7" },
  { note: "B4", frequency: 493.88, key: "u" },

  // Octave 5 (higher register)
  { note: "C5", frequency: 523.25, key: "i" },
  { note: "C#5", frequency: 554.37, key: "9" },
  { note: "D5", frequency: 587.33, key: "o" },
  { note: "D#5", frequency: 622.25, key: "0" },
  { note: "E5", frequency: 659.25, key: "p" },
  { note: "F5", frequency: 698.46, key: "[" },
  { note: "F#5", frequency: 739.99, key: "=" },
  { note: "G5", frequency: 783.99, key: "]" },
  { note: "G#5", frequency: 830.61, key: "Backspace" },
  { note: "A5", frequency: 880.0, key: "\\" },
  { note: "A#5", frequency: 932.33, key: "Enter" },
  { note: "B5", frequency: 987.77, key: "'" },
];

// Real guitar strings (standard tuning) with frets
const GUITAR_STRINGS = [
  { string: "E2", baseFq: 82.41, name: "Low E", color: "#ef4444", key: "1" },
  { string: "A2", baseFq: 110.0, name: "A", color: "#f97316", key: "2" },
  { string: "D3", baseFq: 146.83, name: "D", color: "#eab308", key: "3" },
  { string: "G3", baseFq: 196.0, name: "G", color: "#22c55e", key: "4" },
  { string: "B3", baseFq: 246.94, name: "B", color: "#3b82f6", key: "5" },
  { string: "E4", baseFq: 329.63, name: "High E", color: "#8b5cf6", key: "6" },
];

// Guitar fret mappings (0-12 frets on each string)
const GUITAR_NOTES: Note[] = [
  // Low E string (1st string) - keys q,w,e,r,t,y
  { note: "E2", frequency: 82.41, key: "q" }, // Open
  { note: "F2", frequency: 87.31, key: "w" }, // 1st fret
  { note: "F#2", frequency: 92.5, key: "e" }, // 2nd fret
  { note: "G2", frequency: 98.0, key: "r" }, // 3rd fret
  { note: "G#2", frequency: 103.83, key: "t" }, // 4th fret
  { note: "A2", frequency: 110.0, key: "y" }, // 5th fret

  // A string (2nd string) - keys a,s,d,f,g,h
  { note: "A2", frequency: 110.0, key: "a" }, // Open
  { note: "A#2", frequency: 116.54, key: "s" }, // 1st fret
  { note: "B2", frequency: 123.47, key: "d" }, // 2nd fret
  { note: "C3", frequency: 130.81, key: "f" }, // 3rd fret
  { note: "C#3", frequency: 138.59, key: "g" }, // 4th fret
  { note: "D3", frequency: 146.83, key: "h" }, // 5th fret

  // D string (3rd string) - keys z,x,c,v,b,n
  { note: "D3", frequency: 146.83, key: "z" }, // Open
  { note: "D#3", frequency: 155.56, key: "x" }, // 1st fret
  { note: "E3", frequency: 164.81, key: "c" }, // 2nd fret
  { note: "F3", frequency: 174.61, key: "v" }, // 3rd fret
  { note: "F#3", frequency: 185.0, key: "b" }, // 4th fret
  { note: "G3", frequency: 196.0, key: "n" }, // 5th fret

  // G string (4th string) - keys u,i,o,p,[,]
  { note: "G3", frequency: 196.0, key: "u" }, // Open
  { note: "G#3", frequency: 207.65, key: "i" }, // 1st fret
  { note: "A3", frequency: 220.0, key: "o" }, // 2nd fret
  { note: "A#3", frequency: 233.08, key: "p" }, // 3rd fret
  { note: "B3", frequency: 246.94, key: "[" }, // 4th fret
  { note: "C4", frequency: 261.63, key: "]" }, // 5th fret

  // B string (5th string) - keys j,k,l,;,',enter
  { note: "B3", frequency: 246.94, key: "j" }, // Open
  { note: "C4", frequency: 261.63, key: "k" }, // 1st fret
  { note: "C#4", frequency: 277.18, key: "l" }, // 2nd fret
  { note: "D4", frequency: 293.66, key: ";" }, // 3rd fret
  { note: "D#4", frequency: 311.13, key: "'" }, // 4th fret
  { note: "E4", frequency: 329.63, key: "Enter" }, // 5th fret

  // High E string (6th string) - keys m,,,.,/,shift
  { note: "E4", frequency: 329.63, key: "m" }, // Open
  { note: "F4", frequency: 349.23, key: "," }, // 1st fret
  { note: "F#4", frequency: 369.99, key: "." }, // 2nd fret
  { note: "G4", frequency: 392.0, key: "/" }, // 3rd fret
  { note: "G#4", frequency: 415.3, key: "Shift" }, // 4th fret
  { note: "A4", frequency: 440.0, key: " " }, // 5th fret (spacebar)
];

const INSTRUMENTS = [
  { id: "piano", name: "Piano", icon: "🎹" },
  { id: "guitar", name: "Guitar", icon: "🎸" },
];

export default function Index() {
  const [activeNotes, setActiveNotes] = useState<Set<string>>(new Set());
  const [currentInstrument, setCurrentInstrument] = useState("piano");
  const [isRecording, setIsRecording] = useState(false);
  const [recordedNotes, setRecordedNotes] = useState<RecordedNote[]>([]);
  const [isPlaying, setIsPlaying] = useState(false);
  const [audioContext, setAudioContext] = useState<AudioContext | null>(null);
  const [recordingStartTime, setRecordingStartTime] = useState<number>(0);

  useEffect(() => {
    const context = new (window.AudioContext || window.webkitAudioContext)();
    setAudioContext(context);

    return () => {
      context.close();
    };
  }, []);

  const createOscillator = useCallback(
    (frequency: number, instrument: string) => {
      if (!audioContext) return null;

      if (instrument === "guitar") {
        // Simple, clean guitar sound
        const oscillator = audioContext.createOscillator();
        const gainNode = audioContext.createGain();

        oscillator.connect(gainNode);
        gainNode.connect(audioContext.destination);

        // Clean guitar tone
        oscillator.type = "triangle";
        gainNode.gain.setValueAtTime(0.25, audioContext.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(
          0.01,
          audioContext.currentTime + 2,
        );

        oscillator.frequency.setValueAtTime(
          frequency,
          audioContext.currentTime,
        );
        return { oscillator, gainNode };
      } else {
        // Piano sound
        const oscillator = audioContext.createOscillator();
        const gainNode = audioContext.createGain();

        oscillator.connect(gainNode);
        gainNode.connect(audioContext.destination);

        oscillator.type = "sine";
        gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(
          0.01,
          audioContext.currentTime + 1.5,
        );

        oscillator.frequency.setValueAtTime(
          frequency,
          audioContext.currentTime,
        );
        return { oscillator, gainNode };
      }
    },
    [audioContext],
  );

  const playNote = useCallback(
    (note: Note) => {
      const sound = createOscillator(note.frequency, currentInstrument);
      if (!sound) return;

      // Start all oscillators
      sound.oscillator.start();
      if (sound.harmonics) {
        sound.harmonics.forEach((harmonic) => harmonic.oscillator.start());
      }

      // Stop all oscillators
      const stopTime =
        audioContext!.currentTime + (currentInstrument === "guitar" ? 3 : 2);
      sound.oscillator.stop(stopTime);
      if (sound.harmonics) {
        sound.harmonics.forEach((harmonic) =>
          harmonic.oscillator.stop(stopTime),
        );
      }

      setActiveNotes((prev) => new Set(prev).add(note.note));
      setTimeout(() => {
        setActiveNotes((prev) => {
          const newSet = new Set(prev);
          newSet.delete(note.note);
          return newSet;
        });
      }, 150);

      if (isRecording) {
        const timestamp = Date.now() - recordingStartTime;
        setRecordedNotes((prev) => [
          ...prev,
          {
            note: note.note,
            frequency: note.frequency,
            timestamp,
            instrument: currentInstrument,
          },
        ]);
      }
    },
    [
      createOscillator,
      currentInstrument,
      isRecording,
      recordingStartTime,
      audioContext,
    ],
  );

  const handleKeyPress = useCallback(
    (event: KeyboardEvent) => {
      const notes = currentInstrument === "guitar" ? GUITAR_NOTES : PIANO_NOTES;
      const key = event.key === " " ? " " : event.key.toLowerCase();
      const note = notes.find((n) => n.key === key);
      if (note && !activeNotes.has(note.note)) {
        playNote(note);
      }
    },
    [playNote, activeNotes, currentInstrument],
  );

  useEffect(() => {
    window.addEventListener("keydown", handleKeyPress);
    return () => window.removeEventListener("keydown", handleKeyPress);
  }, [handleKeyPress]);

  const startRecording = () => {
    setIsRecording(true);
    setRecordedNotes([]);
    setRecordingStartTime(Date.now());
  };

  const stopRecording = () => {
    setIsRecording(false);
  };

  const playRecording = async () => {
    if (recordedNotes.length === 0) return;

    setIsPlaying(true);
    const startTime = Date.now();

    for (const recordedNote of recordedNotes) {
      setTimeout(() => {
        const sound = createOscillator(
          recordedNote.frequency,
          recordedNote.instrument,
        );
        if (sound) {
          sound.oscillator.start();
          if (sound.harmonics) {
            sound.harmonics.forEach((harmonic) => harmonic.oscillator.start());
          }

          const stopTime =
            audioContext!.currentTime +
            (recordedNote.instrument === "guitar" ? 2 : 1);
          sound.oscillator.stop(stopTime);
          if (sound.harmonics) {
            sound.harmonics.forEach((harmonic) =>
              harmonic.oscillator.stop(stopTime),
            );
          }
        }
        setActiveNotes((prev) => new Set(prev).add(recordedNote.note));
        setTimeout(() => {
          setActiveNotes((prev) => {
            const newSet = new Set(prev);
            newSet.delete(recordedNote.note);
            return newSet;
          });
        }, 150);
      }, recordedNote.timestamp);
    }

    const totalDuration =
      Math.max(...recordedNotes.map((n) => n.timestamp)) + 2000;
    setTimeout(() => setIsPlaying(false), totalDuration);
  };

  const saveRecording = () => {
    if (recordedNotes.length === 0) return;

    const data = JSON.stringify(recordedNotes, null, 2);
    const blob = new Blob([data], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `soundspace-recording-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const isBlackKey = (note: string) => note.includes("#");

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-accent/5">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl md:text-6xl font-bold bg-gradient-to-r from-primary to-primary/70 bg-clip-text text-transparent mb-4">
            SoundSpace
          </h1>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Create beautiful music with virtual instruments. Use your keyboard
            to play notes and record your compositions.
          </p>
        </div>

        {/* Instrument Selection */}
        <div className="flex justify-center mb-8">
          <div className="flex gap-2 p-2 bg-card rounded-lg border">
            {INSTRUMENTS.map((instrument) => (
              <Button
                key={instrument.id}
                variant={
                  currentInstrument === instrument.id ? "default" : "ghost"
                }
                onClick={() => setCurrentInstrument(instrument.id)}
                className="flex items-center gap-2"
              >
                <span className="text-lg">{instrument.icon}</span>
                {instrument.name}
              </Button>
            ))}
          </div>
        </div>

        {/* Controls */}
        <div className="flex justify-center gap-4 mb-8">
          <Button
            onClick={isRecording ? stopRecording : startRecording}
            variant={isRecording ? "destructive" : "default"}
            className="flex items-center gap-2"
          >
            {isRecording ? (
              <Square className="w-4 h-4" />
            ) : (
              <Volume2 className="w-4 h-4" />
            )}
            {isRecording ? "Stop Recording" : "Start Recording"}
          </Button>

          <Button
            onClick={playRecording}
            disabled={recordedNotes.length === 0 || isPlaying}
            variant="secondary"
            className="flex items-center gap-2"
          >
            {isPlaying ? (
              <Pause className="w-4 h-4" />
            ) : (
              <Play className="w-4 h-4" />
            )}
            {isPlaying ? "Playing..." : "Play Recording"}
          </Button>

          <Button
            onClick={saveRecording}
            disabled={recordedNotes.length === 0}
            variant="outline"
            className="flex items-center gap-2"
          >
            <Download className="w-4 h-4" />
            Save Recording
          </Button>
        </div>

        {/* Instrument Interface */}
        <div className="max-w-6xl mx-auto">
          {currentInstrument === "piano" ? (
            /* Piano Keys */
            <div className="relative bg-card p-6 rounded-lg border">
              <div className="flex justify-center mb-4">
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Keyboard className="w-4 h-4" />
                  Extended Piano - 3 octaves (C3-B5) | Lower: Z-M | Middle: Q-U
                  | Upper: I-'
                </div>
              </div>

              <div className="relative overflow-x-auto">
                <div className="relative flex justify-center min-w-max">
                  {/* White keys */}
                  <div className="flex">
                    {PIANO_NOTES.filter((note) => !isBlackKey(note.note)).map(
                      (note, index) => (
                        <button
                          key={note.note}
                          onClick={() => playNote(note)}
                          className={cn(
                            "w-10 h-32 bg-white border-2 border-gray-300 rounded-b-lg transition-all duration-150 relative overflow-hidden",
                            "hover:bg-gray-50 active:bg-gray-100 hover:shadow-md",
                            "flex flex-col justify-end items-center pb-2",
                            activeNotes.has(note.note) &&
                              "bg-primary/20 transform scale-95 shadow-2xl shadow-primary/50 animate-pulse",
                          )}
                          style={{
                            boxShadow: activeNotes.has(note.note)
                              ? `0 0 25px rgba(139, 92, 246, 0.6)`
                              : undefined,
                          }}
                        >
                          <span className="text-xs font-mono text-gray-600">
                            {note.key === " " ? "SPC" : note.key.toUpperCase()}
                          </span>
                          <span className="text-xs text-gray-500">
                            {note.note}
                          </span>
                        </button>
                      ),
                    )}
                  </div>

                  {/* Black keys */}
                  <div className="absolute flex">
                    {PIANO_NOTES.filter((note) => isBlackKey(note.note)).map(
                      (note, index) => {
                        // Calculate positions for black keys across all octaves
                        const octaveGroup = Math.floor(index / 5);
                        const positionInGroup = index % 5;
                        const baseOffset = octaveGroup * 7 * 40; // 7 white keys per octave, 40px wide each
                        const blackKeyPositions = [30, 70, 150, 190, 230]; // Relative positions within each octave
                        const leftPosition =
                          baseOffset + blackKeyPositions[positionInGroup];

                        return (
                          <button
                            key={note.note}
                            onClick={() => playNote(note)}
                            style={{
                              left: `${leftPosition}px`,
                              boxShadow: activeNotes.has(note.note)
                                ? `0 0 25px rgba(139, 92, 246, 0.8)`
                                : undefined,
                            }}
                            className={cn(
                              "absolute w-7 h-20 bg-gray-800 rounded-b-lg transition-all duration-150 relative overflow-hidden",
                              "hover:bg-gray-700 active:bg-gray-600 hover:shadow-lg",
                              "flex flex-col justify-end items-center pb-1 z-10",
                              activeNotes.has(note.note) &&
                                "bg-primary transform scale-95 shadow-2xl shadow-primary/70 animate-pulse",
                            )}
                          >
                            <span className="text-xs font-mono text-white">
                              {note.key === "Backspace"
                                ? "←"
                                : note.key === "Enter"
                                  ? "↵"
                                  : note.key.toUpperCase()}
                            </span>
                            <span className="text-xs text-gray-300">
                              {note.note}
                            </span>
                          </button>
                        );
                      },
                    )}
                  </div>
                </div>

                {/* Octave labels */}
                <div className="flex justify-center mt-4 gap-8">
                  <div className="text-center">
                    <div className="text-sm font-semibold text-primary">
                      Octave 3
                    </div>
                    <div className="text-xs text-muted-foreground">
                      Lower Register
                    </div>
                  </div>
                  <div className="text-center">
                    <div className="text-sm font-semibold text-primary">
                      Octave 4
                    </div>
                    <div className="text-xs text-muted-foreground">
                      Middle Register
                    </div>
                  </div>
                  <div className="text-center">
                    <div className="text-sm font-semibold text-primary">
                      Octave 5
                    </div>
                    <div className="text-xs text-muted-foreground">
                      Upper Register
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            /* Guitar Fretboard */
            <div className="relative bg-card p-6 rounded-lg border">
              <div className="flex justify-center mb-4">
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Keyboard className="w-4 h-4" />
                  Guitar Fretboard - Use keyboard to play frets on each string
                </div>
              </div>

              <div className="flex items-start gap-4">
                {/* Guitar Headstock */}
                <div className="flex flex-col items-center">
                  <div className="text-xs text-muted-foreground mb-2 font-semibold">
                    HEADSTOCK
                  </div>
                  <div className="relative bg-gradient-to-b from-amber-800 to-amber-900 rounded-t-3xl rounded-b-lg p-3 shadow-lg border-2 border-amber-700">
                    {/* Tuning pegs */}
                    <div className="space-y-[14px]">
                      {GUITAR_STRINGS.map((string, index) => (
                        <div
                          key={string.string}
                          className="flex items-center gap-2 h-8"
                        >
                          {/* Left tuning peg (for even indexed strings) */}
                          {index % 2 === 0 && (
                            <div className="flex items-center gap-1">
                              <div
                                className="w-3 h-3 rounded-full border-2 shadow-inner"
                                style={{
                                  backgroundColor: string.color,
                                  borderColor: string.color,
                                }}
                              />
                              <div className="w-4 h-1 bg-gray-600 rounded-full shadow-sm" />
                            </div>
                          )}

                          {/* Center neck */}
                          <div className="w-2 h-1 bg-gradient-to-r from-amber-600 to-amber-700 rounded-full" />

                          {/* Right tuning peg (for odd indexed strings) */}
                          {index % 2 === 1 && (
                            <div className="flex items-center gap-1">
                              <div className="w-4 h-1 bg-gray-600 rounded-full shadow-sm" />
                              <div
                                className="w-3 h-3 rounded-full border-2 shadow-inner"
                                style={{
                                  backgroundColor: string.color,
                                  borderColor: string.color,
                                }}
                              />
                            </div>
                          )}
                        </div>
                      ))}
                    </div>

                    {/* Headstock logo */}
                    <div className="mt-3 text-center">
                      <div className="text-xs font-bold text-amber-200 tracking-wider">
                        SOUNDSPACE
                      </div>
                      <div className="text-xs text-amber-300 italic">
                        VIRTUAL
                      </div>
                    </div>
                  </div>
                </div>

                {/* Guitar strings */}
                <div className="space-y-4 flex-1">
                  {GUITAR_STRINGS.map((string, stringIndex) => (
                    <div
                      key={string.string}
                      className="flex items-center gap-2"
                    >
                      {/* String name and tuning */}
                      <div className="w-20 text-right">
                        <div
                          className="text-sm font-medium"
                          style={{ color: string.color }}
                        >
                          {string.name}
                        </div>
                        <div className="text-xs text-muted-foreground">
                          {string.string}
                        </div>
                      </div>

                      {/* Frets for this string */}
                      <div className="flex gap-1">
                        {GUITAR_NOTES.filter(
                          (_, index) => Math.floor(index / 6) === stringIndex,
                        ).map((note, fretIndex) => (
                          <button
                            key={`${string.string}-${fretIndex}`}
                            onClick={() => playNote(note)}
                            className={cn(
                              "w-12 h-8 border-2 rounded transition-all duration-150 text-xs font-mono relative overflow-hidden",
                              "hover:scale-105 hover:shadow-md",
                              activeNotes.has(note.note)
                                ? "transform scale-110 shadow-xl animate-pulse"
                                : "bg-secondary hover:bg-secondary/80",
                              fretIndex === 0 &&
                                "border-primary/30 bg-primary/5", // Open string
                            )}
                            style={{
                              backgroundColor: activeNotes.has(note.note)
                                ? string.color
                                : undefined,
                              borderColor: activeNotes.has(note.note)
                                ? string.color
                                : undefined,
                              color: activeNotes.has(note.note)
                                ? "white"
                                : undefined,
                              boxShadow: activeNotes.has(note.note)
                                ? `0 0 20px ${string.color}50`
                                : undefined,
                            }}
                          >
                            <div>
                              {note.key === " "
                                ? "SPC"
                                : note.key.toUpperCase()}
                            </div>
                          </button>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Fret position markers */}
              <div className="mt-4 flex justify-center">
                <div className="flex gap-1 text-xs text-muted-foreground">
                  <span className="w-12 text-center">Open</span>
                  <span className="w-12 text-center">1st</span>
                  <span className="w-12 text-center">2nd</span>
                  <span className="w-12 text-center">3rd</span>
                  <span className="w-12 text-center">4th</span>
                  <span className="w-12 text-center">5th</span>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Recording Status */}
        {isRecording && (
          <div className="fixed top-4 right-4 bg-destructive text-destructive-foreground px-4 py-2 rounded-lg flex items-center gap-2 animate-pulse">
            <div className="w-3 h-3 bg-current rounded-full"></div>
            Recording... ({recordedNotes.length} notes)
          </div>
        )}

        {/* Musical Visual Effects */}
        {activeNotes.size > 0 && (
          <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden">
            {Array.from(activeNotes).map((note, index) => {
              const noteData =
                currentInstrument === "guitar"
                  ? GUITAR_NOTES.find((n) => n.note === note)
                  : PIANO_NOTES.find((n) => n.note === note);
              const frequency = noteData?.frequency || 440;
              const stringColor =
                currentInstrument === "guitar"
                  ? GUITAR_STRINGS.find((s) =>
                      GUITAR_NOTES.filter(
                        (_, i) =>
                          Math.floor(i / 6) === GUITAR_STRINGS.indexOf(s),
                      ).some((gn) => gn.note === note),
                    )?.color || "#8b5cf6"
                  : "#8b5cf6";

              // Calculate note position based on frequency for visual spread
              const notePosition = ((frequency - 80) / 800) * 100; // 0-100% spread

              return (
                <div key={note}>
                  {/* Frequency-based sound wave from instrument */}
                  <div
                    className="absolute transform -translate-x-1/2 -translate-y-1/2"
                    style={{
                      left: `${Math.max(20, Math.min(80, notePosition))}%`,
                      top: `${50 + index * 5}%`,
                    }}
                  >
                    {/* Main pulse */}
                    <div
                      className="w-16 h-16 rounded-full animate-ping opacity-60"
                      style={{
                        backgroundColor: stringColor,
                        animationDuration: `${1.2 - frequency / 1000}s`,
                      }}
                    />
                    {/* Inner glow */}
                    <div
                      className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-8 h-8 rounded-full animate-pulse opacity-80"
                      style={{ backgroundColor: stringColor }}
                    />
                  </div>

                  {/* Sound wave lines emanating from instrument */}
                  <div className="absolute inset-0">
                    {[...Array(4)].map((_, waveIndex) => (
                      <div
                        key={`wave-${waveIndex}`}
                        className="absolute opacity-40"
                        style={{
                          left: `${Math.max(20, Math.min(80, notePosition))}%`,
                          top: `${50 + index * 5}%`,
                          width: `${50 + waveIndex * 30}px`,
                          height: "2px",
                          backgroundColor: stringColor,
                          borderRadius: "1px",
                          transform: `translateX(-50%) translateY(-50%) rotate(${waveIndex * 45}deg)`,
                          animation: `waveExpand 0.8s ease-out ${waveIndex * 0.1}s forwards`,
                        }}
                      />
                    ))}
                  </div>

                  {/* Floating musical note */}
                  <div
                    className="absolute text-xl opacity-70"
                    style={{
                      left: `${Math.max(25, Math.min(75, notePosition + 5))}%`,
                      top: `${45 + index * 8}%`,
                      color: stringColor,
                      animation: `floatUp 1.5s ease-out forwards`,
                      fontSize: `${0.8 + frequency / 1000}rem`,
                    }}
                  >
                    {currentInstrument === "guitar" ? "🎸" : "🎹"}
                  </div>

                  {/* Note name display */}
                  <div
                    className="absolute text-sm font-mono opacity-80 bg-black/20 px-2 py-1 rounded"
                    style={{
                      left: `${Math.max(15, Math.min(85, notePosition))}%`,
                      top: `${40 + index * 8}%`,
                      color: stringColor,
                      animation: `fadeInOut 1s ease-out forwards`,
                    }}
                  >
                    {note}
                  </div>

                  {/* Frequency visualization bars */}
                  <div
                    className="absolute flex items-end gap-1 opacity-50"
                    style={{
                      left: `${Math.max(10, Math.min(90, notePosition - 10))}%`,
                      top: `${65 + index * 5}%`,
                      transform: "translateX(-50%)",
                    }}
                  >
                    {[...Array(5)].map((_, barIndex) => (
                      <div
                        key={`bar-${barIndex}`}
                        className="w-1 rounded-t"
                        style={{
                          height: `${Math.random() * 20 + 10}px`,
                          backgroundColor: stringColor,
                          animation: `barDance 0.5s ease-in-out infinite alternate ${barIndex * 0.1}s`,
                        }}
                      />
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
